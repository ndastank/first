#!/bin/bash
# Bash Menu Script Example

PS3='Please enter your choice: '
options=("Option 1" "Option 2" "Option 3" "Option 4" "Option 5" "Option 6" "Option 7" "Option 8" "Option 9" "Option 10" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "Option 1")
            echo "you chose choice 1"
             cd a && bash run.sh
            ;;
        "Option 2")
            echo "you chose choice 2"
             cd b && bash run.sh
            ;;
        "Option 3")
            echo "you chose choice 3"
             cd c && bash run.sh
            ;;
       "Option 4")
            echo "you chose choice 4"
             cd d && bash run.sh
            ;;
        "Option 5")
            echo "you chose choice 5"
             cd e && bash run.sh
            ;;
            "Option 6")
            echo "you chose choice 6"
             cd ~/bch/a/af && sh run.sh
            ;;
        "Option 7")
            echo "you chose choice 7"
             cd ~/bch/a/ag && sh run.sh
            ;;  
            "Option 8")
            echo "you chose choice 8"
             cd ~/bch/a/ah && sh run.sh
            ;;
        "Option 9")
            echo "you chose choice 9"
             cd ~/bch/a/ai && sh run.sh
            ;;
        "Option 10")
            echo "you chose choice 10"
             cd ~/bch/a/aj && sh run.sh
            ;;
            "Quit")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done
Add break statements wherever you need the select
