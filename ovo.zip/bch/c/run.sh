#!/bin/bash
# Bash Menu Script Example

PS3='Please enter your choice: '
options=("Option 1" "Option 2" "Option 3" "Option 4" "Option 5" "Option 6" "Option 7" "Option 8" "Option 9" "Option 10" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "Option 1")
            echo "you chose choice 1"
             cd ~/bch/c/aa && sh run.sh
            ;;
        "Option 2")
            echo "you chose choice 2"
             cd ~/bch/c/ab && sh run.sh
            ;;
        "Option 3")
            echo "you chose choice 3"
             cd ~/bch/c/ac && sh run.sh
            ;;
       "Option 4")
            echo "you chose choice 4"
             cd ~/bch/c/ad && sh run.sh
            ;;
        "Option 5")
            echo "you chose choice 5"
             cd ~/bch/c/ae && sh run.sh
            ;;
            "Option 6")
            echo "you chose choice 6"
             cd ~/bch/c/af && sh run.sh
            ;;
        "Option 7")
            echo "you chose choice 7"
             cd ~/bch/c/ag && sh run.sh
            ;;  
            "Option 8")
            echo "you chose choice 8"
             cd ~/bch/c/ah && sh run.sh
            ;;
        "Option 9")
            echo "you chose choice 9"
             cd ~/bch/c/ai && sh run.sh
            ;;
        "Option 10")
            echo "you chose choice 10"
             cd ~/bch/c/aj && sh run.sh
            ;;
            "Quit")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done
Add break statements wherever you need the select
