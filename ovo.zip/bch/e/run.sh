#!/bin/bash
# Bash Menu Script Example

PS3='Please enter your choice: '
options=("Option 1" "Option 2" "Option 3" "Option 4" "Option 5" "Option 6" "Option 7" "Option 8" "Option 9" "Option 10" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "Option 1")
            echo "you chose choice 1"
             cd ~/bch/e/aa && sh run.sh
            ;;
        "Option 2")
            echo "you chose choice 2"
             cd ~/bch/e/ab && sh run.sh
            ;;
        "Option 3")
            echo "you chose choice 3"
             cd ~/bch/e/ac && sh run.sh
            ;;
       "Option 4")
            echo "you chose choice 4"
             cd ~/bch/e/ad && sh run.sh
            ;;
        "Option 5")
            echo "you chose choice 5"
             cd ~/bch/e/ae && sh run.sh
            ;;
            "Option 6")
            echo "you chose choice 6"
             cd ~/bch/e/af && sh run.sh
            ;;
        "Option 7")
            echo "you chose choice 7"
             cd ~/bch/e/ag && sh run.sh
            ;;  
            "Option 8")
            echo "you chose choice 8"
             cd ~/bch/e/ah && sh run.sh
            ;;
        "Option 9")
            echo "you chose choice 9"
             cd ~/bch/e/ai && sh run.sh
            ;;
        "Option 10")
            echo "you chose choice 10"
             cd ~/bch/e/aj && sh run.sh
            ;;
            "Quit")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done
Add break statements wherever you need the select
